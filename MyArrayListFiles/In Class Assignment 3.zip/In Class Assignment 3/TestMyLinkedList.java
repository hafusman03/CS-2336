public class TestMyLinkedList
{
  public static void main(String[] args)
  {
    
  }
}
