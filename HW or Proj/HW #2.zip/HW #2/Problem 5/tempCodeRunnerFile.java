
public class TestMyDate
{
    public static void main(String[] args)
    {
        MyDate date = new MyData(34355555133101L);
        System.out.println("Test.");   
    }
}
