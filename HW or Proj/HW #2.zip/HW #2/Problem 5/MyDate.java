
public class MyDate
{
  public int year, month, day;
  
  public MyDate()
  {}


  public MyDate(long elaspedTime)
  {
    
  }

  public void setDate(long elaspedTime)
  {

  }
}
