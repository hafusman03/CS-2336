public class TestProblem5
{
    public static void main(String[] args)
    {
        Person person = new Person();
        Student student = new Student("Junior");
        Employee employee = new Employee();
        Faulty faulty = new  Faulty();
        Staff staff = new Staff();
        MyDate date = new MyDate(34355555133101L);
        System.out.println("Test.");   
    }
}
